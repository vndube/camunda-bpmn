package com.bank.jobworker.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Mono;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import software.amazon.awssdk.core.async.AsyncResponseTransformer;
//import software.amazon.awssdk.services.s3.S3AsyncClient;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

/**
 * Fetches full FD payload from S3 for job worker use.
 * Uses synchronous S3Client (job workers are on dedicated threads, not event loop).
 */
@Service
public class S3PayloadFetcher {

    private static final Logger log = LoggerFactory.getLogger(S3PayloadFetcher.class);
    private static final TypeReference<Map<String, Object>> MAP_TYPE = new TypeReference<>() {};

    private final S3Client s3Client;
    private final ObjectMapper objectMapper;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    @Value("${aws.s3.prefix:fd-requests/}")
    private String prefix;

    public S3PayloadFetcher(S3Client s3Client, ObjectMapper objectMapper) {
        this.s3Client     = s3Client;
        this.objectMapper = objectMapper;
    }

    /**
     * Fetch and deserialize the FD payload from S3.
     * Key: {prefix}{applicationId}.json
     */
    public Map<String, Object> fetchPayload(String applicationId) {
        String key = prefix + applicationId + ".json";
        log.debug("Fetching payload from S3 key={}", key);

        GetObjectRequest req = GetObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .build();

        try (InputStream is = s3Client.getObject(req)) {
            Map<String, Object> payload = objectMapper.readValue(is, MAP_TYPE);
            log.info("Payload fetched from S3 applicationId={}", applicationId);
            return payload;
        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch payload from S3 key=" + key, e);
        }
    }
    
//    public Mono<Map<String, Object>> fetchPayload(String bucket, String key, String applicationId) {
//        GetObjectRequest req = GetObjectRequest.builder()
//                .bucket(bucket)
//                .key(key)
//                .build();
//
//        
//        return Mono.fromFuture(() -> s3Client.getObject(req, AsyncResponseTransformer.toBytes()))
//                .map(responseBytes -> {
//                    try {
//                        // Jackson's ObjectMapper can read directly from byte[]
//                        Map<String, Object> payload = objectMapper.readValue(responseBytes.asByteArray(), MAP_TYPE);
//                        log.info("Payload fetched from S3 applicationId={}", applicationId);
//                        return payload;
//                    } catch (IOException e) {
//                        throw new RuntimeException("Failed to parse JSON from S3 key=" + key, e);
//                    }
//                })
//                .onErrorMap(e -> new RuntimeException("Failed to fetch payload from S3 key=" + key, e));
//    }

}
