package com.bank.jobworker.service;

import java.time.Duration;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * HTTP client from Job Worker → FD Domain Service.
 * All calls are blocking (join) because Zeebe job handlers run on worker threads.
 * WebClient is still used for consistent error handling and timeout control.
 */
@Service
public class FdDomainClient {

    private static final Logger log = LoggerFactory.getLogger(FdDomainClient.class);

    private final WebClient webClient;
    private final Duration  timeout;

    public FdDomainClient(
            WebClient.Builder builder,
            @Value("${fd-domain.base-url}") String baseUrl,
            @Value("${fd-domain.timeout-seconds:20}") int timeoutSec) {
        this.webClient = builder
            .baseUrl(baseUrl)
            .defaultHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
            .build();
        this.timeout = Duration.ofSeconds(timeoutSec);
    }

    // ── Validate FD ──────────────────────────────────────────────────────

    public record ValidationResult(boolean valid, String reason, Map<String, Object> details) {}

    public ValidationResult validateFd(String applicationId, Map<String, Object> payload) {
        log.info("Calling domain validation applicationId={}", applicationId);
        return webClient.post()
            .uri("/internal/fd/validate")
            .bodyValue(payload)
            .retrieve()
            .bodyToMono(ValidationResult.class)
            .timeout(timeout)
            .doOnError(e -> log.error("Domain validate call failed applicationId={}", applicationId, e))
            .block();
    }

    // ── Persist draft ─────────────────────────────────────────────────────

    public record PersistDraftResult(String applicationId, String status) {}

    public PersistDraftResult persistDraft(String applicationId) {
        log.info("Calling domain persist draft applicationId={}", applicationId);
        return webClient.post()
            .uri("/internal/fd/{id}/draft", applicationId)
            .retrieve()
            .bodyToMono(PersistDraftResult.class)
            .timeout(timeout)
            .block();
    }

    // ── Open in CBS ───────────────────────────────────────────────────────

    public record CbsOpenResult(
        String applicationId,
        String fdAccountNumber,
        String status,
        String cbsTransactionId
    ) {}

    public CbsOpenResult openInCbs(String applicationId, Map<String, Object> payload) {
        log.info("Calling domain CBS open applicationId={}", applicationId);
        return webClient.post()
            .uri("/internal/fd/cbs-open")
            .bodyValue(payload)
            .retrieve()
            .bodyToMono(CbsOpenResult.class)
            .timeout(timeout)
            .doOnError(e -> log.error("Domain CBS open call failed applicationId={}", applicationId, e))
            .block();
    }
}
